package com.example.kosharyan.model;

public class About {
   public String name;
   public String image;
   public String titel;


    public About(String name, String image, String titel){
        this.name=name;
        this.image=image;
        this.titel=titel;
}



}
