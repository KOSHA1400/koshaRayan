package com.example.kosharyan.model;

public class Product {
   public  String image;
   public  String titel;
   public  String desc;
    public Product(String image,String titel,String desc){
        this.image=image;
        this.titel=titel;
        this.desc=desc;
    }

}
