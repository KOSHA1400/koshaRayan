package com.example.kosharyan.model;

public class Costomer {
    public String titel;
    public String description;
    public String image;
    public Costomer(String titel, String description,String image) {
        this.titel = titel;
        this.description = description;
        this.image=image;

    }
}