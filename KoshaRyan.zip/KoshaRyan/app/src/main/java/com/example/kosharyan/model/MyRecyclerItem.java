package com.example.kosharyan.model;

public class MyRecyclerItem {
}
