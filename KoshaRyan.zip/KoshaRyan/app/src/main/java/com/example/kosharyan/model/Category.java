package com.example.kosharyan.model;

public class Category {
  public String categories;

   public Category(String categories){
       this.categories=categories;

   }


}
