package com.example.kosharyan.model;

public class Eftekharat {

        public  String name;
        public  String image;
        public  String description;
        public Eftekharat( String name,String image, String description){
            this.name=name;
            this.image=image;
            this.description =description;
        }
    }

