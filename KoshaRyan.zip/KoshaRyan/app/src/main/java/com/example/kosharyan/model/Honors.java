package com.example.kosharyan.model;

public class Honors {
    public  Integer image;
    public Honors(Integer image){
        this.image=image;

    }
}
