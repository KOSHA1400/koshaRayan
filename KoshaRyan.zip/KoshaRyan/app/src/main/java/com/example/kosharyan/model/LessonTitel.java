package com.example.kosharyan.model;

public class LessonTitel {
    public  String caption;
    public LessonTitel(String caption){
        this.caption=caption;
    }
}
